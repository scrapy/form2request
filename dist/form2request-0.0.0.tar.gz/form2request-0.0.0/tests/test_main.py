def test_main():
    assert True
